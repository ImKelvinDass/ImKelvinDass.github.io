The IPC and media-owner routing design is informed by SpotiQueue by brkr1
(MIT; license included). Vendored LightMessaging headers are taken from that
repository's vendor/LightMessaging directory, with Apple bootstrap/sandbox
copyright and license notices preserved in the source headers.

YouTube Queue is a separate companion. It does not distribute or replace
YTKACE, NextUp 3, CanvasSync, CanvasSyncYTFix, SpotiLoveReborn or SpotiQueue.
Those packages retain their original ownership, licenses and behavior.
