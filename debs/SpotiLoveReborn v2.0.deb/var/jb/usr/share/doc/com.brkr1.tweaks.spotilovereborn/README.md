# SpotiLoveReborn 2.0

Original tweak by brkr1, released under the MIT License (see `copyright`).
Rootless iOS 17 package maintained by Kelvin (KiLlErZoN3).

## 2.0
- Version aligned with SpotiQueue 2.0, which requires this exact version.
- No functional changes from 1.9.
