# SpotiQueue 2.0

Original tweak by brkr1, released under the MIT License (see `copyright`).
Rootless iOS 17 package maintained by Kelvin (KiLlErZoN3).

## 2.0
- Smooth queue reordering and first-in, first-out additions.
- Compact controls that match the Lock Screen player, with a smaller heart.
- Taller queue panel and stable artwork.
- Requires SpotiLoveReborn 2.0.
- Replaces the separate compact-controls and reorder-fix add-ons, so do not install those alongside it.
